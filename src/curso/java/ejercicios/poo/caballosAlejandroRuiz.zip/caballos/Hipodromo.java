package curso.java.ejercicios.poo.caballos;

public class Hipodromo {
	private Caballo[] caballos;
	private Carrera carrera;
	public static void main(String[] args) {
		Caballo[] caballos=new Caballo[3];
		Carrera carrera=new Carrera("Carrera 1", 100, caballos);
		Hipodromo h = new Hipodromo(caballos, carrera);
		
		Apostante a1=new Apostante("Alex", 1000);
		Apostante a2=new Apostante("Juan", 2000);
		a1.setApuesta(a1.apostar(carrera));
		a2.setApuesta(a2.apostar(carrera));
		Apostante[] apostantes= {a1, a2};
		Caballo ganador=carrera.iniciarCarrera();
		h.comprobarGanador(ganador, apostantes);
	}
	public Hipodromo(Caballo[] caballos, Carrera carrera) {

		for (int i = 0; i < caballos.length; i++) {
			caballos[i]=new Caballo();
		}

	}
	
	public void comprobarGanador(Caballo caballoGanador, Apostante[] apostantes) {
		for (int i = 0; i < apostantes.length; i++) {
			if(apostantes[i].getApuesta().getCaballoApostado() == caballoGanador.getDorsal()) {
				System.out.println("Ganador: "+apostantes[i].getNombre());
				apostantes[i].setSaldo(apostantes[i].getSaldo()+apostantes[i].getApuesta().getCantidad());//Recupera el dinero que apostó
				for (int j = 0; j < apostantes.length; j++) {//Recibe cada cantidad apostada por cada jugador.
					if(j!=i) {
						apostantes[i].setSaldo(apostantes[i].getSaldo()+apostantes[j].getApuesta().getCantidad());
					}
				}
			}
			System.out.println("Saldo de "+apostantes[i].getNombre()+": "+apostantes[i].getSaldo()+" €.");
		}
		
	}
}
